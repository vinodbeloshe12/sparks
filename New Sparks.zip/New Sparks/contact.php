<?php
include 'header.php';
?>


			<div class="navbar navbar-fixed-top" role="navigation">
					

			<div class="container">
					<div class="navbar-header">
					<!-- COLLAPSE BUTTON -->
						 <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
							<i class="fa fa-bars fa-2x"></i>
						</button>
					<div id="mylogol"><a class="navbar-brand" href="index.php"><img src="img/logo.png" alt="" /></a> </div>
					</div>
					<div class="navbar-collapse collapse">
					
						<!-- MENU -->
						<ul style="margin-right:0px;" class="nav navbar-nav navbar-right">
							<li>
							<a href="index.php">Home</a>					
							</li>
							<li><a href="about.php">About</a>
								
							</li>
							<li><a href="services.php">Services</a>
							</li>
							<li><a href="portfolio.php">Portfolio</a>
							</li>
							<li><a class="active" href="contact.php">Contact</a>
							</li>
						</ul>
						</div>
							</div>
						</div>
					</header>
				<!-- //HEADER -->
			
			
			
		<!--//GOOGLE MAP - ADD YOUR ADDRESS AT THE BOTTOM OF THE PAGE -->
			<div class="container pad90">
        	<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3769.8919201437548!2d72.92827280000002!3d19.112396800000013!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3be7c7be076e2415%3A0xb5a1c6206dc69a2!2sVikroli+Railway+Station!5e0!3m2!1sen!2sin!4v1441194600861" width="100%" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
			</div>
        <!-- // End Google Map -->
		
		
		
		<div class="container pad90">
		<div class="col-md-4">
			<!-- <p class="light">
				Do you need a Design, have a question or comment? Please feel free to send us an email or fill in our handy contact form. 
				We aim to reply within 24 hours.
			</p> -->
			
			
			
			<div class="myborder">
<div class="myheadc2"><i class="fa fa-phone mybox"></i>&nbsp;&nbsp;&nbsp;Contacts</div>
	</div>
			
					<p class="pad30">Email :</span>&nbsp <br/> sparks@sparksdesignsolutions.com <br>
info@sparksdesignsolutions.com

</a><br></p><br>
<p>Agriculture :<p>
					<p>Phone :<br/></span> +91 9167768584 <br>
+ 91 9167766872
				</p>
			</p>
<p>Parmaceutical :
					<p>Phone :<br/></span> +91 9820267440

				</p>
			</div>
		
		<div class="col-md-8">
		<div class="myborder">
<div class="myheadc1"><i class="fa fa-map-marker mybox"></i>&nbsp;&nbsp;&nbsp;Drop a Line</div>
	</div>
		<div class="contact_form pad30">  
							<div id="note"></div>
							<div id="fields">
							<form id="ajax-contact-form">
							<input class="col-xs-12 col-md-12" type="text" name="name" value="" placeholder="Your Name" />
							<input class="col-xs-12 col-md-12" type="text" name="email" value="" placeholder="Your Email"/>
							<input class="col-xs-12 col-md-12" type="text" name="subject" value="" placeholder="Subject"  />
							<textarea name="message" id="message" class="col-xs-12  col-md-12" placeholder="Your Message..."></textarea>
							<div class="clear"></div>
							<input type="submit" class="btn marg-right10" value="submit" />
							<input type="reset" class="btn" value="reset" />
							<div class="clear"></div>
							</form>  
						</div>
					</div>                   
				</div>                	
			</div>
		
	<!-- FOOTER SECTION -->	

	<?php include("footer.php"); ?>
