<?php
include("mychk.php");
$catid = $_GET['catid'];
include 'db.php';

$SQL = "DELETE FROM gallery WHERE id = '$catid'";
mysqli_query($con,$SQL);

print "<script>location.href = 'gallerydetails.php'</script>";
?>