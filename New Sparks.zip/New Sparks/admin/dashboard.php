<?php
include("header.php");
?>



      

        <div id="content" class="dash-page">

            <div id="dash-bar" class="top-bar box">

                <div id="stat1" class="stat up item"><span>Rs. 5845.00</span>Earnings this month</div>
                <div id="stat2" class="stat item"><span>Rs. 1200.00</span>Payments due</div>
                <div id="stat3" class="stat down item"><span>Rs. 25,900</span>Outstanding payments</div>
               

                <div id="dash-cal" class="item">
                    <span id="cal-day">19 Nov</span>
                    <span class="icon-calendarthree item-icon"></span>
                    <p id="cal-events">No events today</p>
                </div>

                <span id="tb-handle"></span>

            </div>

          

         
            <div id="intro-box" class="box g8">
                <div class="header"><span class="accent grad2">Welcome to Sparks Designs Solutions!</span></div>
                <div id="intro" class="content scroll ov-no">
	                <div class="scroll-cont">
	                	
	                </div>
                </div>
            </div>

           

         

        </div>

        <!--MODAL WINDOWS-->

       

	</div><!--END WRAPPER-->

	<div id="load"><div id="spinner"></div></div>

	
	
	<?php
include("footer.php");
?>