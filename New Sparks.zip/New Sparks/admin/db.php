<?php
//$con = mysqli_connect("localhost","technfox_sparks","CI-J1Ko0hfKH","technfox_sparks");
$con = mysqli_connect("localhost","tfvinod","{P~34XN@]CJn","tfsparks"); 

if(mysqli_connect_errno()){
echo "Database did not connect";
exit();
}
?>