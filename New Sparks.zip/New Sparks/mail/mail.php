<?php 
$errors = '';
//$myemail = $_POST['emailid'];
$myemail = 'vinodbeloshe122@gmail.com';
?>
<html>
<head>
<title>SparksDesignSolutions.Com Mail Sender</title>
      <style type="text/css">
         /* Client-specific Styles */
         #outlook a {padding:0;} /* Force Outlook to provide a "view in browser" menu link. */
         body{width:100% !important; -webkit-text-size-adjust:100%; -ms-text-size-adjust:100%; margin:0; padding:0;}
         /* Prevent Webkit and Windows Mobile platforms from changing default font sizes, while not breaking desktop design. */
         .ExternalClass {width:100%;} /* Force Hotmail to display emails at full width */
         .ExternalClass, .ExternalClass p, .ExternalClass span, .ExternalClass font, .ExternalClass td, .ExternalClass div {line-height: 100%;} /* Force Hotmail to display normal line spacing.  */
         #backgroundTable {margin:0; padding:0; width:100% !important; line-height: 100% !important;}
         img {outline:none; text-decoration:none;border:none; -ms-interpolation-mode: bicubic;}
         a img {border:none;}
         .image_fix {display:block;}
         p {margin: 0px 0px !important;}
		 .link{color:#fff; text-decoration:none;}
         table td {border-collapse: collapse;}
         table { border-collapse:collapse; mso-table-lspace:0pt; mso-table-rspace:0pt; }
          a {color: #fff;text-decoration: none;text-decoration:none!important;} 
         /*STYLES*/
         table[class=full] { width: 100%; clear: both; }
         /*IPAD STYLES*/
         @media only screen and (max-width: 640px) {
         a[href^="tel"], a[href^="sms"] {
         text-decoration: none;
         color: #fff; /* or whatever your want */
         pointer-events: none;
         cursor: default;
         }
         .mobile_link a[href^="tel"], .mobile_link a[href^="sms"] {
         text-decoration: default;
         color:#fff !important;
         pointer-events: auto;
         cursor: default;
         }
         table[class=devicewidth] {width: 440px!important;text-align:center!important;}
         table[class=devicewidthinner] {width: 420px!important;text-align:center!important;}
         img[class=banner] {width: 440px!important;height:220px!important;}
         img[class=colimg2] {width: 440px!important;height:220px!important;}
         
         
         }
         /*IPHONE STYLES*/
         @media only screen and (max-width: 480px) {
         a[href^="tel"], a[href^="sms"] {
         text-decoration: none;
         color: #ffffff; /* or whatever your want */
         pointer-events: none;
         cursor: default;
         }
         .mobile_link a[href^="tel"], .mobile_link a[href^="sms"] {
         text-decoration: default;
         color: #ffffff !important; 
         pointer-events: auto;
         cursor: default;
         }
         table[class=devicewidth] {width: 280px!important;text-align:center!important;}
         table[class=devicewidthinner] {width: 260px!important;text-align:center!important;}
         img[class=banner] {width: 280px!important;height:140px!important;}
         img[class=colimg2] {width: 280px!important;height:140px!important;}
         td[class="padding-top15"]{padding-top:15px!important;}
         
        
         }
      </style>
</head>

<body>
<?


	$strTo = $myemail;
	$strSubject = "Newsletter from - Sparks Design Solutions";
	$strHeader = "Content-type: text/html; charset=windows-874\n"; // or UTF-8 //
	$strHeader .= "From: Sparks Design Solutions<sparks@sparksdesignsolutions.com>\nReply-To: sparks@sparksdesignsolutions.com";
	$strVar = "Newsletter for Sparks Design Solutions";
	$strMessage = "
  
    <table width='100%'   cellpadding='0' cellspacing='0' border='0' background='http://www.sparksdesignsolutions.com/mail/img/Sparks.jpg' style='background-image: url('http://www.sparksdesignsolutions.com/mail/img/Sparks.jpg');'>
   <tbody>
      <tr>
    <td>




<table width='100%'   cellpadding='0' cellspacing='0' border='0'>
   <tbody>
      <tr>
         <td>
            <table width='600' cellpadding='0' cellspacing='0' border='0' align='center'>
               <tbody>
                  <tr>
                     <td width='100%'>
                        <table width='600' align='center' cellspacing='0' cellpadding='0' border='0'>
                           <tbody>
                              <tr>
                                 
                                 <td align='center'>
                                    <div>
                                       <a href='#151344b06e7061f7_'><img width='600' border='0' height='220' alt='' style='display:block;border:none;outline:none;text-decoration:none' src='http://www.sparksdesignsolutions.com/mail/img/s2.png' class='CToWUd'></a>
                                    </div>
                                 </td>
                              </tr>
                           </tbody>
                        </table>
                        
                     </td>
                  </tr>
               </tbody>
            </table>
         </td>
      </tr>
   </tbody>
</table>
  

<table width='100%'   cellpadding='0' cellspacing='0' border='0'>
   <tbody>
      <tr>
         <td>
            <table width='600' align='center' cellspacing='0' cellpadding='0' border='0'>
               <tbody>
                  <tr>
                     <td align='center' height='30' style='font-size:1px;line-height:1px'>&nbsp;</td>
                  </tr>
               </tbody>
            </table>
         </td>
      </tr>
   </tbody>
</table>
   

<table width='100%'   cellpadding='0' cellspacing='0' border='0'>
   <tbody>
      <tr>
         <td>
            <table width='600' cellpadding='0' cellspacing='0' border='0' align='center'>
               <tbody>
                  <tr>
                     <td width='100%'>
                        <table width='600' align='center' cellspacing='0' cellpadding='0' border='0'>
                           <tbody>
                              <tr>
                                 <td align='center' style='font-family:Helvetica,arial,sans-serif;font-size:24px;color:#ffffff;padding:4px 0' bgcolor='#d41b29'>
                                   Core Services
                                 </td>
                              </tr>
                           </tbody>
                        </table>
                     </td>
                  </tr>
               </tbody>
            </table>
         </td>
      </tr>
   </tbody>
</table>
 

<table width='100%'  cellpadding='0' cellspacing='0' border='0'>
   <tbody>
      <tr>
         <td>
            <table width='600' cellpadding='0' cellspacing='0' border='0' align='center'>
               <tbody>
                  <tr>
                     <td width='100%'>
                        <table bgcolor='#ffffff' width='600' cellpadding='0' cellspacing='0' border='0' align='center'>
                           <tbody>
                              <tr>
                                 <td>
                                    <table width='290' align='left' border='0' cellpadding='0' cellspacing='0'>
                                       <tbody>
                                          
                                          <tr>
                                             <td width='100%' height='20'></td>
                                          </tr>
                                          
                                          <tr>
                                             <td>
                                                
                                                <table width='270' align='right' border='0' cellpadding='0' cellspacing='0'>
                                                   <tbody>
                                                      
                                                      <tr>
                                                         <td width='270' align='center'>
                                                           <a href='http://www.sparksdesignsolutions.com/services.php' target='_blank'> <img src='https://ci3.googleusercontent.com/proxy/gFCg0DMN9I1hjb20rLG-o0bw6N91GL45DoRHzoZSEusegXWAzJzFvJvim3Be6Y7H2bEjKhqsahvC9_jTEq8et2xbzA8inwTb9w=s0-d-e1-ft#http://www.sparksdesignsolutions.com/mail/img/A.png' border='0' width='270' height='150' style='display:block;border:none;outline:none;text-decoration:none' class='CToWUd'></a>
                                                         </td>
                                                      </tr>
                                                      
                                                      <tr>
                                                         <td width='270' bgcolor='#d41b29' height='30'>
                                                            <table width='228' align='left' border='0' cellpadding='0' cellspacing='0' style='border:1px solid #d41b29'>
                                                               <tbody>
                                                                  <tr>
                                                                     <td style='font-family:Helvetica,arial,sans-serif;font-size:15px;color:#ffffff;padding-left:10px' align='left' height='30'>
                                                                   <a style='color:#fff;text-decoration:none' href='http://www.sparksdesignsolutions.com/services.php' target='_blank'> Creative Packaging Designs</a>
                                                                     </td>
                                                                  </tr>
                                                               </tbody>
                                                            </table>
                                                            <table width='38' align='right' border='0' cellpadding='0' cellspacing='0' style='border:1px solid #000000'>
                                                               <tbody>
                                                                  <tr>
                                                                     <td style='font-family:Helvetica,arial,sans-serif;font-weight:bold;font-size:15px;color:#ffffff' bgcolor='#000000' align='center' height='30'>
                                                                   <a style='color:#fff;text-decoration:none' href='http://www.sparksdesignsolutions.com/services.php' target='_blank'> &gt; </a>
                                                                     </td>
                                                                  </tr>
                                                               </tbody>
                                                            </table>
                                                         </td>
                                                      </tr>
                                                      
                                                   </tbody>
                                                </table>
                                             </td>
                                          </tr>
                                          
                                       </tbody>
                                    </table>
                                    
                                    
                                    <table width='290' align='right' border='0' cellpadding='0' cellspacing='0'>
                                       <tbody>
                                          
                                          <tr>
                                             <td width='100%' height='20'></td>
                                          </tr>
                                          
                                          <tr>
                                             <td>
                                                
                                                <table width='270' align='left' border='0' cellpadding='0' cellspacing='0'>
                                                   <tbody>
                                                      
                                                      <tr>
                                                         <td width='270' align='center'>
                                                       <a href='http://www.sparksdesignsolutions.com/services.php' target='_blank'><img src='https://ci5.googleusercontent.com/proxy/CoEq-c67zUbmcbsqw25jI7Q1CvKh7crhxNKU4oC7fAUC5SzrZ5-x8yXZhfc85noHaDrIgq8bpQUm97f1IdGT59oQz9d8T213TQ=s0-d-e1-ft#http://www.sparksdesignsolutions.com/mail/img/D.png' alt='' border='0' width='270' height='150' style='display:block;border:none;outline:none;text-decoration:none' class='CToWUd'></a>
                                                         </td>
                                                      </tr>
                                                      
                                                      <tr>
                                                         <td width='270' bgcolor='#d41b29' height='30'>
                                                            <table width='228' align='left' border='0' cellpadding='0' cellspacing='0' style='border:1px solid #d41b29'>
                                                               <tbody>
                                                                  <tr>
                                                             <td style='font-family:Helvetica,arial,sans-serif;font-size:15px;color:#ffffff;padding-left:10px' height='30' align='left'>
                                                                      <a style='color:#fff;text-decoration:none' href='http://www.sparksdesignsolutions.com/services.php' target='_blank'>  Brand Promotion </a>
                                                                     </td>
                                                                  </tr>
                                                               </tbody>
                                                            </table>
                                                            <table width='38' align='right' border='0' cellpadding='0' cellspacing='0' style='border:1px solid #000000'>
                                                               <tbody>
                                                                  <tr>
                                                                      <td style='font-family:Helvetica,arial,sans-serif;font-weight:bold;font-size:15px;color:#ffffff' bgcolor='#000000' align='center' height='30'>
                                                                    <a style='color:#fff;text-decoration:none' href='http://www.sparksdesignsolutions.com/services.php' target='_blank'> &gt;</a>
                                                                     </td>
                                                                  </tr>
                                                               </tbody>
                                                            </table>
                                                         </td>
                                                      </tr>
                                                      
                                                      
                                                   </tbody>
                                                </table>
                                             </td>
                                          </tr>
                                          
                                       </tbody>
                                    </table>
                                    
                                 </td>
                              </tr>
                           </tbody>
                        </table>
                     </td>
                  </tr>
               </tbody>
            </table>
         </td>
      </tr>
   </tbody>
</table>


<table width='100%'  cellpadding='0' cellspacing='0' border='0'>
   <tbody>
      <tr>
         <td>
            <table width='600' cellpadding='0' cellspacing='0' border='0' align='center'>
               <tbody>
                  <tr>
                     <td width='100%'>
                        <table bgcolor='#ffffff' width='600' cellpadding='0' cellspacing='0' border='0' align='center'>
                           <tbody>
                              <tr>
                                 <td>
                                    <table width='290' align='left' border='0' cellpadding='0' cellspacing='0'>
                                       <tbody>
                                          
                                          <tr>
                                             <td width='100%' height='10'></td>
                                          </tr>
                                          
                                          <tr>
                                             <td>
                                                
                                                <table width='270' align='right' border='0' cellpadding='0' cellspacing='0'>
                                                   <tbody>
                                                      
                                                      <tr>
                                                         <td width='270' align='center'>
                                                          <a href='http://www.sparksdesignsolutions.com/services.php' target='_blank'>  <img src='https://ci5.googleusercontent.com/proxy/HEAzt2csjKuWlygLX_m6DUjSeG3zikqgHRYcq8oiduCNHcLUskDCXV_-DRl1skE26GlJR4XRoVmgq3RDPOlbyz-QKj2j1Ht2bg=s0-d-e1-ft#http://www.sparksdesignsolutions.com/mail/img/H.png' alt='' border='0' width='270' height='150' style='display:block;border:none;outline:none;text-decoration:none' class='CToWUd'></a>
                                                         </td>
                                                      </tr>
                                                      
                                                      <tr>
                                                         <td width='270' bgcolor='#d41b29' height='30'>
                                                            <table width='228' align='left' border='0' cellpadding='0' cellspacing='0' style='border:1px solid #d41b29'>
                                                               <tbody>
                                                                  <tr>
                                                                     <td style='font-family:Helvetica,arial,sans-serif;font-size:15px;color:#ffffff;padding-left:10px' align='left' height='30'>
                                                                        <a style='color:#fff;text-decoration:none' href='http://www.sparksdesignsolutions.com/services.php' target='_blank'>Photography</a>
                                                                     </td>
                                                                  </tr>
                                                               </tbody>
                                                            </table>
                                                            <table width='38' align='right' border='0' cellpadding='0' cellspacing='0' style='border:1px solid #000000'>
                                                               <tbody>
                                                                  <tr>
                                                                      <td style='font-family:Helvetica,arial,sans-serif;font-weight:bold;font-size:15px;color:#ffffff' bgcolor='#000000' align='center' height='30'>
                                                                        <a style='color:#fff;text-decoration:none' href='http://www.sparksdesignsolutions.com/services.php' target='_blank'>&gt;</a>
                                                                     </td>
                                                                  </tr>
                                                               </tbody>
                                                            </table>
                                                         </td>
                                                      </tr>
                                                      
                                                   </tbody>
                                                </table>
                                             </td>
                                          </tr>
                                          
                                          
                                          <tr>
                                             <td width='100%' height='10'></td>
                                          </tr>
                                          
                                       </tbody>
                                    </table>
                                    
                                    
                                    <table width='290' align='right' border='0' cellpadding='0' cellspacing='0'>
                                       <tbody>
                                          
                                          <tr>
                                             <td width='100%' height='10'></td>
                                          </tr>
                                          
                                          <tr>
                                             <td>
                                                
                                                <table width='270' align='left' border='0' cellpadding='0' cellspacing='0'>
                                                   <tbody>
                                                      
                                                      <tr>
                                                         <td width='270' align='center'>
                                                          <a href='http://www.sparksdesignsolutions.com/services.php' target='_blank'>  <img src='https://ci5.googleusercontent.com/proxy/YDPniGyKZ9lAbLdmfG-lzCN-kRY3EOxm1R-NkGuEFpTp8nLd3mJctGZ0slxrOMv5Lf8R-MDQXmu1axwnVmgtm_rUjVIoJlgvO0I=s0-d-e1-ft#http://www.sparksdesignsolutions.com/mail/img/A1.png' alt='' border='0' width='270' height='150' style='display:block;border:none;outline:none;text-decoration:none' class='CToWUd'></a>
                                                         </td>
                                                      </tr>
                                                      
                                                      <tr>
                                                         <td width='270' bgcolor='#d41b29' height='30'>
                                                            <table width='228' align='left' border='0' cellpadding='0' cellspacing='0' style='border:1px solid #d41b29'>
                                                               <tbody>
                                                                  <tr>
                                                                     <td style='font-family:Helvetica,arial,sans-serif;font-size:15px;color:#ffffff;padding-left:10px' height='30' align='left'>
                                                                      <a style='color:#fff;text-decoration:none' href='http://www.sparksdesignsolutions.com/services.php' target='_blank'>  Translations &amp; Typesetting</a>
                                                                     </td>
                                                                  </tr>
                                                               </tbody>
                                                            </table>
                                                            <table width='38' align='right' border='0' cellpadding='0' cellspacing='0' style='border:1px solid #000000'>
                                                               <tbody>
                                                                  <tr>
                                                                     <td style='font-family:Helvetica,arial,sans-serif;font-weight:bold;font-size:15px;color:#ffffff' bgcolor='#000000' align='center' height='30'>
                                                                        <a style='color:#fff;text-decoration:none' href='http://www.sparksdesignsolutions.com/services.php' target='_blank'>&gt;</a>
                                                                     </td>
                                                                  </tr>
                                                               </tbody>
                                                            </table>
                                                         </td>
                                                      </tr>
                                                      
                                                      
                                                   </tbody>
                                                </table>
                                             </td>
                                          </tr>
                                          
                                          
                                          <tr>
                                             <td width='100%' height='20'></td>
                                          </tr>
                                          
                                       </tbody>
                                    </table>
                                    
                                 </td>
                              </tr>
                           </tbody>
                        </table>
                     </td>
                  </tr>
               </tbody>
            </table>
         </td>
      </tr>
   </tbody>
</table>


<table width='100%'   cellpadding='0' cellspacing='0' border='0'>
   <tbody>
      <tr>
         <td>
            <table width='600' align='center' cellspacing='0' cellpadding='0' border='0'>
               <tbody>
                  <tr>
                     <td align='center' height='30' style='font-size:1px;line-height:1px'>&nbsp;</td>
                  </tr>
               </tbody>
            </table>
         </td>
      </tr>
   </tbody>
</table>
 

<table width='100%'   cellpadding='0' cellspacing='0' border='0'>
   <tbody>
      <tr>
         <td>
            <table width='600' cellpadding='0' cellspacing='0' border='0' align='center'>
               <tbody>
                  <tr>
                     <td width='100%'>
                        <table bgcolor='#d41b29' width='600' align='center' cellspacing='0' cellpadding='0' border='0'>
                           <tbody>
                              <tr>
                                 <td align='center' style='font-family:Helvetica,arial,sans-serif;font-size:24px;color:#ffffff;padding:4px 0' bgcolor='#d41b29'>
                                    View our Work
                                 </td>
                              </tr>
                           </tbody>
                        </table>
                     </td>
                  </tr>
               </tbody>
            </table>
         </td>
      </tr>
   </tbody>
</table>
 




<table width='100%'   cellpadding='0' cellspacing='0' border='0'>
   <tbody>
      <tr>
         <td>
            <table width='600' cellpadding='0' cellspacing='0' border='0' align='center'>
               <tbody>
                  <tr>
                     <td width='100%'>
                        <table bgcolor='#ffffff' width='600' cellpadding='0' cellspacing='0' border='0' align='center'>
                           <tbody>
                              
                              <tr>
                                 <td height='20'></td>
                              </tr>
                              
                              <tr>
                                 <td>
                                    <table width='560' align='center' border='0' cellpadding='0' cellspacing='0'>
                                       <tbody>
                                          <tr>
                                             <td>
                                                
                                                <table width='600' align='left' border='0' cellpadding='0' cellspacing='0'>
                                                   <tbody>
                                                      
                                                      <tr>
                                                         <td width='140' height='90' align='center'>
                                                            <a href='http://www.sparksdesignsolutions.com/portfolio.php' target='_blank'> <img src='https://ci6.googleusercontent.com/proxy/0R9KzL4xNWVaP0mwJG2ATE4FnOLn4FIxxZRt-IZN40xAFB8-8nU-wxp0ak_tfXvXqcrvxVTPGZPUEPJyV1Ydi_wgA0qcspup_20=s0-d-e1-ft#http://www.sparksdesignsolutions.com/mail/img/EE.png' alt='' border='0' width='140' height='90' style='display:block;border:none;outline:none;text-decoration:none' label='articleimage' class='CToWUd'></a>
                                                         </td>
														 <td width='5'></td>
														  <td width='140' height='90' align='center'>
                                                              <a href='http://www.sparksdesignsolutions.com/portfolio.php' target='_blank'> <img src='https://ci4.googleusercontent.com/proxy/7wjkAK1u0UXOokaxEi8p4a0EItIz7mz758PZ9AAwzY3GiFlt0gTQtCFxvUWc9-Fav8VOE5GYfjfhwDZ7u_NKeaqqjbtfhPC_sF0=s0-d-e1-ft#http://www.sparksdesignsolutions.com/mail/img/E2.png' alt='' border='0' width='140' height='90' style='display:block;border:none;outline:none;text-decoration:none' label='articleimage' class='CToWUd'></a>
                                                         </td>
														 <td width='5'></td>
														  <td width='140' height='90' align='center'>
                                                             <a href='http://www.sparksdesignsolutions.com/portfolio.php' target='_blank'>  <img src='https://ci5.googleusercontent.com/proxy/OIqO_lBpwwLkV_P57gv7sCO7___LNuZ_jVbKTYPC1HQmiWKtQ-kmpZ84uA38JEqmbNMkje7pmJa60m0Bu-DhkVwI9ILkiOBpYg=s0-d-e1-ft#http://www.sparksdesignsolutions.com/mail/img/O.png' alt='' border='0' width='140' height='90' style='display:block;border:none;outline:none;text-decoration:none' label='articleimage' class='CToWUd'></a>
                                                         </td>
														 <td width='5'></td>
														  <td width='140' height='90' align='center'>
                                                             <a href='http://www.sparksdesignsolutions.com/portfolio.php' target='_blank'>  <img src='https://ci6.googleusercontent.com/proxy/Dm84YkDHLuWje6naU5m5Lkmm_PkyGQE87wz5NjwGzMUcyrXsvcHN7ghiwK6YGDnQvIN2gO8SruXSZFQj2-AYFDd5eaG4Jd__4t8=s0-d-e1-ft#http://www.sparksdesignsolutions.com/mail/img/AA.png' alt='' border='0' width='140' height='90' style='display:block;border:none;outline:none;text-decoration:none' label='articleimage' class='CToWUd'> </a>
                                                         </td>
                                                      </tr>
                                                   </tbody>
                                                </table>
                                                
                                                
                                                
                                             </td>
                                          </tr>
                                       </tbody>
                                    </table>
                                 </td>
                              </tr>
                              
                              <tr>
                                 <td height='20'></td>
                              </tr>
                              
                              
                              <tr>
                                 <td width='100%' bgcolor='#d41b29' height='3' style='font-size:1px;line-height:1px'>&nbsp;</td>
                              </tr>
                              
                           </tbody>
                        </table>
                     </td>
                  </tr>
               </tbody>
            </table>
         </td>
      </tr>
   </tbody>
</table>


<table width='100%'   cellpadding='0' cellspacing='0' border='0'>
   <tbody>
      <tr>
         <td>
            <table width='600' align='center' cellspacing='0' cellpadding='0' border='0'>
               <tbody>
                  <tr>
                     <td align='center' height='30' style='font-size:1px;line-height:1px'>&nbsp;</td>
                  </tr>
               </tbody>
            </table>
         </td>
      </tr>
   </tbody>
</table>
   

<table width='100%' bgcolor='#d41b29' cellpadding='0' cellspacing='0' border='0'>
   <tbody>
      <tr>
         <td>
            <table width='600' cellpadding='0' cellspacing='0' border='0' align='center'>
               <tbody>
                  <tr>
                     <td width='100%'>
                        <table bgcolor='#d41b29' width='600' cellpadding='0' cellspacing='0' border='0' align='center'>
                           <tbody>
                              <tr>
                                 <td>
                                    <table width='290' align='left' border='0' cellpadding='0' cellspacing='0'>
                                       <tbody>
                                          
                                          <tr>
                                             <td width='100%' height='20'></td>
                                          </tr>
                                          
                                          <tr>
                                             <td style='font-family:Helvetica,arial,sans-serif;font-size:18px;color:#ffffff;text-align:left'>
                                               Sparks Design Solutions
                                             </td>
                                          </tr>
                                          
                                          <tr>
                                             <td width='100%' height='10'></td>
                                          </tr>
                                          
                                          <tr>
                                             <td style='font-family:Helvetica,arial,sans-serif;font-size:14px;color:#ffffff;text-align:left'>
                                                M/s. Sparks is a designing firm which provides Designing Solutions. Sparks is the place where sparkling ideas for Designing &amp; Concepts are Blooming. 
                                             </td>
                                          </tr>
                                          
                                          <tr>
                                             <td width='100%' height='10'></td>
                                          </tr>
                                          
                                       </tbody>
                                    </table>
                                    
                                    
                                    <table width='200' align='right' border='0' cellpadding='0' cellspacing='0'>
                                       <tbody>
                                          
                                          <tr>
                                             <td width='100%' height='20'></td>
                                          </tr>
                                          
                                          <tr>
                                             <td style='font-family:Helvetica,arial,sans-serif;font-size:18px;color:#ffffff;text-align:left'>
                                                Contact Us
                                             </td>
                                          </tr>
                                          
                                          <tr>
                                             <td width='100%' height='10'></td>
                                          </tr>
                                          
                                          <tr>
                                             <td style='font-family:Helvetica,arial,sans-serif;font-size:14px;color:#fff;text-align:left'>
                                                Sparks Design Solutions, <br>
                                               Vikhroli East, <br>
                                               Mumbai, Maharashtra 400083.<br>
                                               9167766872 / 9820267440
                                             </td>
                                          </tr>
                                          
                                          <tr>
                                             <td width='100%' height='20'></td>
                                          </tr>
                                          
                                       </tbody>
                                    </table>
                                    
                                 </td>
                              </tr>
                           </tbody>
                        </table>
                     </td>
                  </tr>
               </tbody>
            </table>
         </td>
      </tr>
   </tbody>
</table>


<table width='100%'   cellpadding='0' cellspacing='0' border='0'>
   <tbody>
      <tr>
         <td>
            <table width='600' cellpadding='0' cellspacing='0' border='0' align='center'>
               <tbody>
                  <tr>
                     <td width='100%'>
                        <table width='600' cellpadding='0' cellspacing='0' border='0' align='center'>
                           <tbody>
                              
                              <tr>
                                 <td width='100%' height='20'></td>
                              </tr>
                              
                              
                              
                              <tr>
                                 <td width='100%' height='20'></td>
                              </tr>
                              
                           </tbody>
                        </table>
                     </td>
                  </tr>
               </tbody>
            </table>
         </td>
      </tr>
   </tbody>
</table>
	   
</td>	   
      </tr>
   </tbody>
</table>
       

	";
	 $result = @mail($strTo,$strSubject,$strMessage,$strHeader);  // @ = No Show Error //
         
        if($result) { 
         echo "Send Successfully. <a href='http://www.sparksdesignsolutions.com/mail/'>Go Back</a>"; 
        } else { 
            echo 'FAILED<br>'; 
        } 
         

	

?>
</body>
</html>
