<?php
include 'header.php';
?>

				<div class="navbar navbar-fixed-top" role="navigation">
					

			<div class="container">
					<div class="navbar-header">
					<!-- COLLAPSE BUTTON -->
						 <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
							<i class="fa fa-bars fa-2x"></i>
						</button>
						<!-- LOGO -->
					<div id="mylogol"><a class="navbar-brand" href="index.php"><img src="img/logo.png" alt="" /></a> </div>
					
					</div>
					<div class="navbar-collapse collapse">
					
						<!-- MENU -->
						<ul style="margin-right:0px;" class="nav navbar-nav navbar-right">
							<li>
							<a href="index.php">Home</a>					
							</li>
							<li><a href="about.php">About</a>
								
							</li>
							<li><a  class="active" href="services.php">Services</a>
							</li>
							<li><a href="portfolio.php">Portfolio</a>
							</li>
							<li><a href="contact.php">Contact</a>
							</li>
						</ul>
						</div>
							</div>
						</div>
					</header><!-- //HEADER -->
	
	
		<div class="container pad150">
			<div class="col-md-6 ">

				<h3>Team Spirit</h3>
					<p>
						Few can name an umpteen ferryboat that isn't an ansate plain. A bait is a distance's helium. 
						Few can name an umpteen ferryboat that isn't an ansate plain. A  A window sees a newsprint bait distance's is a  helium 
						Some posit the squa mate selection as a jetting playground distance.
					</p>
				</div>
			
			<div class="col-md-6">
				<h3>Sparks design solutions</h3>
					<p>
						M/s. Sparks is a designing firm which provides Designing Solutions. Sparks is the place where sparkling ideas for Designing
						& Concepts are Blooming. We believe that designing is not only making a good layout but it should communicate the desired message to the End-user. All works in Sparks is handled by two efficient persons who have more than15 years of experience & expertise in designing field. We’ve coined our name as Sparks Design Solutions, just to convey that we have the spark to create new designs and ideas. We’ve created the logo in the same line with a Pencil which is a 
						designing tool along with the Sparks and the letter “A” designed in the way that it shows the growth sign.
					</p>
				</div>
				
			
				</div>
					<div class="pad45"></div>
					
				<div class="container">
				
		<!-- 1 -->
				<div class="col-xs-4 col-sm-2 col-md-1">
					<div class="hi-icon-wrap2 hi-icon-effect-a hi-icon-effect-a1 ">
						<a href="javascript:{}" class="hi-icon2 fa fa-pencil fadein"></a>
					</div>
				</div>
				<div class="col-xs-8 col-sm-10 col-md-5">
					<div class="pad15"></div>
						<h4>Creative Packaging Designs</h4>
						<p class="padt5">Creative Packaging Designs- Labels, Pouches, Cartons, Shippers and DFU.</p>
					</div>
					
		<!-- 2 -->
				<div class="col-xs-4 col-sm-2 col-md-1">
					<div class="hi-icon-wrap2 hi-icon-effect-a hi-icon-effect-a1 ">
						<a href="javascript:{}" class="hi-icon2 fa fa-trophy fadein"></a>
					</div>
				</div>
				<div class="col-xs-8 col-sm-10 col-md-5">
					<div class="pad15"></div>
						<h4>Brand Promotion</h4>
						<p class="padt5">Brand Promotion - Campaigns, Conceptualization, POP (Gift Items) & Creative Ideas. </p>
					</div>
				
				
				</div>
					
						
				<div class="container">
				
		<!-- 3 -->
	
				<div class="col-xs-4 col-sm-2 col-md-1">
					<div class="hi-icon-wrap2 hi-icon-effect-a hi-icon-effect-a1 ">
						<a href="javascript:{}" class="hi-icon2 fa fa-camera fadein"></a>
					</div>
				</div>
				<div class="col-xs-8 col-sm-10 col-md-5">
					<div class="pad15"></div>
						<h4>Photography</h4>
						<p class="padt5">Photography - Industrial, commercial , Model shoot & Table Top.</p>
					</div>
					
		<!-- 4 -->
				<div class="col-xs-4 col-sm-2 col-md-1">
					<div class="hi-icon-wrap2 hi-icon-effect-a hi-icon-effect-a1 ">
						<a href="javascript:{}" class="hi-icon2 fa fa-edit fadein"></a>
					</div>
				</div>
				<div class="col-xs-8 col-sm-10 col-md-5">
					<div class="pad15"></div>
						<h4>Translations & Typesetting</h4>
						<p class="padt5">Translations, Typesetting & Adaptation in all Indian languages and Printing as well.</p>
					</div>
				
				</div>
					
				
				<div class="container pad5">
					<div class="row">
	<div class="col-md-12">
	<div class="pad45 myborder2"></div>
	<div class="myborder2">
				<marquee class="mytxtc"><b style="color:red;">TRANSLATION & TYPESETTING IN ALL INDIAN LANGUAGES & FOREIGN LANGUAGES : - </b> <span style="color:black; font-weight:normal;"> Hindi, Marathi, Gujarati, Assamese,  Bengali, Punjabi, Oriya, Tamil, Telugu, Kannada, Malayalam & Urdu
Manipuri, Khasi, Mizó - Chinese, Japanese, German, Spanish, French, ltalian, Portuguses,
Nepalese, Dutch,  Korean, Russian, Arabic ... ext.</span></marquee>
				</div></div></div></div>
		<!--CHARTS-->
			
		<!--//CHARTS-->	
		
		
		<section id="follow">
			
				<!-- <div class="center follow light">
				
				<a href="contact.html" class="big_button bouncein">Contact Us Today</a>
			</div> -->
		</section>  
	
	<!-- FOOTER SECTION -->	
<?php include("footer.php"); ?>
